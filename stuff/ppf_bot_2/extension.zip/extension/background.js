async function isDebug() {
  return (await getFromStorage('debug')) === true;
}

async function getFromStorage(key) {
  return new Promise((resolve) => {
    chrome.storage.local.get(key, (result) => {
      if (chrome.runtime.lastError) {
        console.error('[DarkBot][Extension] storage read failed', key, chrome.runtime.lastError.message);
      }
      resolve(result[key]);
    });
  });
}

function xorWithKey(data, key) {
  const result = [];
  for (let i = 0; i < data.length; i++) {
    result.push(String.fromCharCode(data.charCodeAt(i) ^ key.charCodeAt(i % key.length)));
  }
  return result.join('');
}

function base64Encode(str) {
  try {
    return btoa(unescape(encodeURIComponent(str)));
  } catch {
    return btoa(str);
  }
}

function base64Decode(str) {
  try {
    return decodeURIComponent(escape(atob(str)));
  } catch {
    return atob(str);
  }
}

const SECRET_KEY = 'darkbot-secret-key-v1';

function decrypt(value) {
  if (!value) return value;
  try {
    const xored = base64Decode(value);
    return xorWithKey(xored, SECRET_KEY);
  } catch {
    return value;
  }
}

async function sendTelegramNotify(siteName, text) {
  const tokenRaw = await getFromStorage('telegram_bot_api');
  const chatIdRaw = await getFromStorage('telegram_chat_id');
  const token = decrypt(tokenRaw || '');
  const chatId = decrypt(chatIdRaw || '');

  console.log('[DarkBot][Telegram] configuration', {
    siteName,
    hasToken: Boolean(token),
    hasChatId: Boolean(chatId),
  });

  if (!token || !chatId) {
    if (await isDebug()) console.warn('[Telegram] skipped: token or chat ID is missing');
    return;
  }

  const messageText = text || (siteName ? `Captcha required on ${siteName}` : 'Captcha required');

  try {
    const response = await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        chat_id: chatId,
        text: messageText,
      }),
    });
    if (await isDebug()) console.debug('[Telegram] response', { siteName, status: response.status, ok: response.ok });
    if (!response.ok) console.error('[DarkBot][Telegram] API rejected message', await response.text());
  } catch (e) {
    console.error('Telegram notification failed:', e);
  }
}

async function sendDiscordNotify(siteName, description) {
  const webhookUrlRaw = await getFromStorage('discord_webhook_url');
  const userIdRaw = await getFromStorage('discord_user_id');
  const webhookUrl = decrypt(webhookUrlRaw || '');
  const userId = decrypt(userIdRaw || '');

  console.log('[DarkBot][Discord] configuration', {
    siteName,
    hasWebhook: Boolean(webhookUrl),
    hasUserId: Boolean(userId),
  });

  if (!webhookUrl) {
    if (await isDebug()) console.warn('[Discord] skipped: webhook is missing');
    return;
  }

  const content = userId ? `<@${userId}>` : '';
  const desc = description || (siteName ? `Captcha required on ${siteName}` : 'Captcha required');

  try {
    const response = await fetch(webhookUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        username: 'DarkBot',
        embeds: [
          {
            title: 'Captcha Required',
            description: desc,
            color: 0xFF0000,
            footer: {
              text: 'DarkBot',
            },
            timestamp: new Date().toISOString(),
          },
        ],
        content,
      }),
    });
    if (await isDebug()) console.debug('[Discord] response', { siteName, status: response.status, ok: response.ok });
    if (!response.ok) console.error('[DarkBot][Discord] webhook rejected message', await response.text());
  } catch (e) {
    console.error('Discord notification failed:', e);
  }
}

let lastSentTelegram = null;
let lastSentDiscord = null;

function notifyLock(last, key, ttl) {
  ttl = ttl || 10000;
  const now = Date.now();
  if (last && last.key === key && now - last.ts < ttl) {
    return false;
  }
  return true;
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'inject-storage') {
    if (!sender.tab?.id || sender.frameId == null) {
      sendResponse({ injected: false, error: 'No sender tab available' });
      return;
    }

    (async () => {
      try {
        const data = await chrome.storage.local.get(null);
        await chrome.scripting.executeScript({
          target: { tabId: sender.tab.id, frameIds: [sender.frameId] },
          world: 'MAIN',
          func: (storageData) => {
            const storageKey = String.fromCharCode(95, 95, 68, 65, 82, 75, 66, 79, 84, 95, 69, 88, 84, 69, 78, 83, 73, 79, 78, 95, 83, 84, 79, 82, 65, 71, 69, 95, 95);
            const readyKey = String.fromCharCode(95, 95, 68, 65, 82, 75, 66, 79, 84, 95, 69, 88, 84, 69, 78, 83, 73, 79, 78, 95, 83, 84, 79, 82, 65, 71, 69, 95, 82, 69, 65, 68, 89, 95, 95);
            window[storageKey] = storageData || {};
            window[readyKey] = true;
          },
          args: [data || {}],
        });
        sendResponse({ injected: true });
      } catch (error) {
        console.error('[DarkBot][Extension] storage injection failed', error);
        sendResponse({ injected: false, error: error?.message || String(error) });
      }
    })();

    return true;
  }

  if (msg.type === 'inject-bundle') {
    if (!sender.tab?.id || sender.frameId == null) {
      sendResponse({ injected: false, error: 'No sender tab available' });
      return;
    }
    chrome.scripting.executeScript({
      target: { tabId: sender.tab.id, frameIds: [sender.frameId] },
      files: ['pkg-h4x.js'],
      world: 'MAIN',
    }).then(() => {
      sendResponse({ injected: true });
    }).catch((error) => {
      console.error('[DarkBot][Extension] bundle injection failed', error);
      sendResponse({ injected: false, error: error?.message || String(error) });
    });
    return true;
  }

  if (msg.type === 'captcha' || msg.type === 'captcha_solving' || msg.type === 'idle_captcha') {
    (async () => {
      if (await isDebug()) console.debug('[DarkBot][Extension] notification received', {
        type: msg.type,
        siteName: msg.siteName,
        hasText: Boolean(msg.text),
        hasDescription: Boolean(msg.description),
      });
      const siteName = msg.siteName || (typeof document !== 'undefined' ? document.domain : undefined);
      const text = msg.text;
      const description = msg.description;

      const tgText = text || (siteName ? `Captcha required on ${siteName}` : (msg.type === 'idle_captcha' ? 'Waiting for captcha solution' : 'Captcha required'));
      const dcDesc = description || (siteName ? `Captcha required on ${siteName}` : (msg.type === 'idle_captcha' ? 'Waiting for captcha solution' : 'Captcha required'));

      const notificationKey = msg.type + '|' + siteName;
      const tgKey = notificationKey;
      if (notifyLock(lastSentTelegram, tgKey)) {
        lastSentTelegram = { key: tgKey, ts: Date.now() };
        sendTelegramNotify(siteName, tgText);
      } else {
        if (await isDebug()) console.debug('[Telegram] duplicate notification suppressed', { type: msg.type, siteName });
      }

      const dcKey = notificationKey;
      if (notifyLock(lastSentDiscord, dcKey)) {
        lastSentDiscord = { key: dcKey, ts: Date.now() };
        sendDiscordNotify(siteName, dcDesc);
      } else {
        if (await isDebug()) console.debug('[Discord] duplicate notification suppressed', { type: msg.type, siteName });
      }

      if (await isDebug()) console.debug('[Extension] notification dispatch complete', { type: msg.type, siteName });
      sendResponse({ received: true });
    })();
  }
  return true;
});
